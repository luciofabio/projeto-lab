/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package system;

import connection.ConnectionFactory;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import pessoa.Aluno;
import pessoa.Paciente;
import pessoa.Recepcionista;
import pessoa.Supervisor;

/**
 *
 * @author Peu
 */
public class SystemClinica {
    
    /*
    methods that will add at the especific type in your respective db
    */
    public void cadBD(Aluno al, String tipoPessoa){
        if(verifyCad(al) == false){
            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            CallableStatement cs = null;
            String sql = "INSERT INTO `db_clinica`.`pessoa` (`codPessoa`, `login`, `senha`, `tipoPessoa`) VALUES (?, ?, ?, ?)";
            try {
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, al.getCod());
                stmt.setString(2, al.getLogin());
                stmt.setString(3, al.getSenha());
                stmt.setString(4, tipoPessoa);
                stmt.executeUpdate();
                
                String sql2 = "INSERT INTO `db_clinica`.`aluno` (`codAluno`, `nome`, `cpf`, `curso`) VALUES (?, ?, ?, ?)";
                stmt = con.prepareStatement(sql2);
                stmt.setString(1, String.valueOf(al.getCod()));
                stmt.setString(2, al.getNome());
                stmt.setString(3, al.getCpf());
                stmt.setString(4, al.getCurso());
                stmt.executeUpdate();
            } catch (SQLException e) {
                System.out.println("ERRO");
            } finally {
                ConnectionFactory.closeConnection(con, stmt);
                ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
                JOptionPane.showMessageDialog(null, "Usuário cadastrado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
            }
        }else{
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconError.png");
            JOptionPane.showMessageDialog(null, "Matricula em uso ou usuário já existente", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }
    
    public boolean verifyCad(Aluno al){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM `db_clinica`.`pessoa` WHERE `codPessoa` = ?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setString(1, String.valueOf(al.getCod()));
            rs = stmt.executeQuery();
            if(rs.next()){
                return true;
            }
            sql = "SELECT * FROM `db_clinica`.`pessoa` WHERE `login` = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, al.getLogin());
            rs = stmt.executeQuery();
            if(rs.next()){
                return true;
            }            
        } catch (SQLException e) {
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return false;
    }
    
    public void cadBD(Supervisor sup, String tipoPessoa){
        if(verifyCad(sup) == false){
            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            CallableStatement cs = null;
            String sql = "INSERT INTO `db_clinica`.`pessoa` (`login`, `senha`, `tipoPessoa`) VALUES (?, ?, ?)";
            try {
                String data = dataAtual();
                stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                stmt.setString(1, sup.getLogin());
                stmt.setString(2, sup.getSenha());
                stmt.setString(3, tipoPessoa);
                stmt.executeUpdate();
                
                rs = stmt.getGeneratedKeys();
                rs.next();
                int key = rs.getInt(1);
                sql = "INSERT INTO `db_clinica`.`supervisor` (`codSupervisor`, `nome`, `curso`) VALUES (?, ?, ?)";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, key);
                stmt.setString(2, sup.getNome());
                stmt.setString(3, sup.getCurso());
                stmt.executeUpdate();
            } catch (SQLException e) {
                
            }finally {
                ConnectionFactory.closeConnection(con, stmt, rs);
                ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
                JOptionPane.showMessageDialog(null, "Usuário cadastrado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
            }
        }else{
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconError.png");
            JOptionPane.showMessageDialog(null, "Usuário já existente", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }    
    
    public boolean verifyCad(Supervisor sup){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM `db_clinica`.`pessoa` WHERE `login` = ?";
        try {            
            stmt = con.prepareStatement(sql);
            stmt.setString(1, sup.getLogin());
            rs = stmt.executeQuery();
            if(rs.next()){
                return true;
            }            
        } catch (SQLException e) {
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return false;
    }
    
    public void cadBD(Recepcionista rec, String tipoPessoa){
        if(verifyCad(rec) == false){
            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            CallableStatement cs = null;
            String sql = "INSERT INTO `db_clinica`.`pessoa` (`login`, `senha`, `tipoPessoa`) VALUES (?, ?, ?)";
            try {
                String data = dataAtual();
                stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                stmt.setString(1, rec.getLogin());
                stmt.setString(2, rec.getSenha());
                stmt.setString(3, tipoPessoa);
                stmt.executeUpdate();
                
                rs = stmt.getGeneratedKeys();
                rs.next();
                int key = rs.getInt(1);
                sql = "INSERT INTO `db_clinica`.`recepcionista` (`codRecepcionista`, `nome`, `data`, `cpf`, `endereco`) "
                        + "VALUES (?, ?, ?, ?, ?)";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, key);
                stmt.setString(2, rec.getNome());
                stmt.setString(3, rec.getData());
                stmt.setString(4, rec.getCpf());
                stmt.setString(5, rec.getEndereco());
                stmt.executeUpdate();
            } catch (SQLException e) {
                System.out.println("pi pop, error");
            }finally {
                ConnectionFactory.closeConnection(con, stmt, rs);
                ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
                JOptionPane.showMessageDialog(null, "Usuário cadastrado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
            }
        }else{
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconError.png");
            JOptionPane.showMessageDialog(null, "Usuário já existente", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }
    
    public boolean verifyCad(Recepcionista rec){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM `db_clinica`.`pessoa` WHERE `login` = ?";
        try {            
            stmt = con.prepareStatement(sql);
            stmt.setString(1, rec.getLogin());
            rs = stmt.executeQuery();
            if(rs.next()){
                return true;
            }            
        } catch (SQLException e) {
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return false;
    }
    
    public void cadBD(Paciente pac){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        CallableStatement cs = null;
        String sql = null;
        try {
            sql = "INSERT INTO `db_clinica`.`paciente` (`nome`, `data`, `cpf`, `endereco`, `dataInicioPeriodo`, "
                    + "`dataFinalPeriodo`, `areaAt1`) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, pac.getNome());
            stmt.setString(2, pac.getData());
            stmt.setString(3, pac.getCpf());
            stmt.setString(4, pac.getEndereco());
            stmt.setString(5, dataAtual());
            stmt.setString(6, dataAtual());
            stmt.setString(7, pac.getAreaAt1());
            stmt.executeUpdate();

            rs = stmt.getGeneratedKeys();
            rs.next();
            int key = rs.getInt(1);
            if(pac.getAreaAt2().equals("Escolha") == false){
                sql = "UPDATE `db_clinica`.`paciente` SET `areaAt2` = ? WHERE cod = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, pac.getAreaAt2());
                stmt.setInt(2, key);
                stmt.executeUpdate();
            }else {
                sql = "UPDATE `db_clinica`.`paciente` SET `areaAt2` = ? WHERE cod = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, "Aberto");
                stmt.setInt(2, key);
                stmt.executeUpdate();
            }

            //mudando a data final do periodo
            sql = "CALL `db_clinica`.`calcPeriodo`(?)";
            cs = con.prepareCall(sql);
            cs.setInt(1, key);
            cs.execute();
        } catch (SQLException e){
            System.out.println("Erro");
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
            JOptionPane.showMessageDialog(null, "Paciente cadastrado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }
    
    public void apagarConta(int cod){
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "DELETE FROM `db_clinica`.`pessoa` WHERE `codPessoa` = ?";
        try {
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, cod);
            stmt.executeUpdate();
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
            JOptionPane.showMessageDialog(null, "Conta deletada", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        } catch (SQLException e){

        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    public void cadAg(int codP, String dataAg, String areaAt, String status){
        String sql = "INSERT INTO `db_clinica`.`agConsulta`(`codPaciente`, `dataConsulta`, `areaAtendimento`, `statusAgendamento`)"
                + " VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        try{
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, codP);
            stmt.setString(2, dataAg);
            stmt.setString(3, areaAt);
            stmt.setString(4, status);
            stmt.executeUpdate();
        }catch(SQLException e){
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
            JOptionPane.showMessageDialog(null, "Agendamento criado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }
    
    public void editarAg(int codA, String dataAg, String areaAt, String status){
        String sql = "UPDATE `db_clinica`.`agConsulta` "
                   + "SET `dataConsulta` = ?, `areaAtendimento` = ?, `statusAtendimento` = ? "
                   + "WHERE `codAgConsulta` = ?";
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, dataAg);
            stmt.setString(2, areaAt);
            stmt.setString(3, status);
            stmt.setInt(4, codA);
            stmt.executeUpdate();
        }catch(SQLException e){
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
            ImageIcon icon = new ImageIcon("C:\\Users\\Peu\\Desktop\\icons\\iconOK.png");
            JOptionPane.showMessageDialog(null, "Agendamento criado", "Mensagem do sistema", JOptionPane.ERROR_MESSAGE, icon);
        }
    }
    
    public String dataAtual(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
	Date date = new Date(); 
        return dateFormat.format(date);
    }
    
    public void editarDD(int cod, Aluno al){
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "UPDATE `db_clinica`.`aluno` "
                   + "SET `nome` = ?, `cpf` = ?, `curso` = ? "
                   + "WHERE `codAluno` = ?";
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, al.getNome());
            stmt.setString(2, al.getCpf());
            stmt.setString(3, al.getCurso());
            stmt.setInt(4, cod);
            stmt.executeUpdate();
            
            //se o campo de senha nova estiver preenchido irá trocar a senha atual
            if(al.getSenha().equals("") == false){
                sql = "UPDATE `db_clinica`.`pessoa` SET `senha` = ? WHERE `codPessoa` = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, al.getSenha());
                stmt.setInt(2, cod);
                stmt.executeUpdate();
            }
        } catch (SQLException e){
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    public void editarDD(int cod, Supervisor sup){
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "UPDATE `db_clinica`.`supervisor` "
                   + "SET `nome` = ?, `curso` = ? "
                   + "WHERE `codSupervisor` = ?";
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, sup.getNome());
            stmt.setString(2, sup.getCurso());
            stmt.setInt(3, cod);
            stmt.executeUpdate();
            
            //se o campo de senha nova estiver preenchido irá trocar a senha atual
            if(sup.getSenha().equals("") == false){
                sql = "UPDATE `db_clinica`.`pessoa` SET `senha` = ? WHERE `codPessoa` = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, sup.getSenha());
                stmt.setInt(2, cod);
                stmt.executeUpdate();
            }
        } catch (SQLException e){
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    public void editarDD(int cod, Recepcionista rec){
        PreparedStatement stmt = null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "UPDATE `db_clinica`.`Recepcionista` "
                   + "SET `nome` = ?, `data` = ?, `cpf` = ?, `endereco` = ? "
                   + "WHERE `codRecepcionista` = ?";
        try{
            stmt = con.prepareStatement(sql);
            stmt.setString(1, rec.getNome());
            stmt.setString(2, rec.getData());
            stmt.setString(3, rec.getCpf());
            stmt.setString(4, rec.getEndereco());
            stmt.setInt(5, cod);
            stmt.executeUpdate();
            
            //se o campo de senha nova estiver preenchido irá trocar a senha atual
            if(rec.getSenha().equals("") == false){
                sql = "UPDATE `db_clinica`.`pessoa` SET `senha` = ? WHERE `codPessoa` = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, rec.getSenha());
                stmt.setInt(2, cod);
                stmt.executeUpdate();
            }
        } catch (SQLException e){
            
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
}