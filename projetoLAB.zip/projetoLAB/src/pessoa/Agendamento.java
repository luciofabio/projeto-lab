/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import java.util.Scanner;

/**
 *
 * @author Peu
 */
public class Agendamento {
    
    //codigo do agendamento
    private int codAG;
    //nome do paciente
    private String nomePac;
    // codigo do paciente
    private int codPac;
    //area de atendimento
    private String areaAt;
    //data da consulta
    private String dataCons;

    public Agendamento(String nomePac, int codPac, String areaAt, String dataCons) {
        this.nomePac = nomePac;
        this.codPac = codPac;
        this.areaAt = areaAt;
        this.dataCons = dataCons;
    }

    public Agendamento() {}
    
    public int getCodAG() {
        return codAG;
    }

    public void setCodAG(int codAG) {
        this.codAG = codAG;
    }

    public String getNomePac() {
        return nomePac;
    }

    public void setNomePac(String nomePac) {
        this.nomePac = nomePac;
    }

    public int getCodPac() {
        return codPac;
    }

    public void setCodPac(int codPac) {
        this.codPac = codPac;
    }

    public String getAreaAt() {
        return areaAt;
    }

    public void setAreaAt(String areaAt) {
        this.areaAt = areaAt;
    }

    public String getDataCons() {
        return dataCons;
    }

    public void setDataCons(String dataCons) {
        this.dataCons = dataCons;
    }
    
    public Agendamento novoAg(){
        /*
        private String nomePac;
        private int codPac;
        private String areaAt;
        private String dataCons;
        */
        Scanner scan = new Scanner(System.in);
        System.out.print("Nome do paciente: ");
        nomePac = scan.nextLine();
        codPac = scan.nextInt();
        scan.nextLine();
        System.out.print("Area de atendimento: ");
        areaAt = scan.nextLine();
        System.out.print("Data do atendimento: ");
        dataCons = scan.nextLine();
        return new Agendamento(nomePac, 1, areaAt, dataCons);
    }
    
    public Agendamento editarAg(Agendamento ag){
        Scanner scan = new Scanner(System.in);
        System.out.print("Area de atendimento: ");
        areaAt = scan.nextLine();
        System.out.print("Data do atendimento: ");
        dataCons = scan.nextLine();
        if(ag.getAreaAt().equals(areaAt) && ag.getDataCons().equals(dataCons)){
            return ag;
        }
        ag.setAreaAt(areaAt);
        ag.setDataCons(dataCons);
        return ag;
    }
    
    public void removerAg(){
        String sql = "DELETE FROM " + "`Clinica`.`Agendamento` " + "WHERE codAg = ?";    
    }
    
}
