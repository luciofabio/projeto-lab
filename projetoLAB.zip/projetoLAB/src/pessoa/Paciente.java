/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import java.util.Scanner;

/**
 *
 * @author Peu
 */
public class Paciente{
    
    private String nome;
    private String data;
    private String cpf;
    private String endereco;
    private String areaAt1;
    private String areaAt2;

    public Paciente(String nome, String data, String cpf, String endereco, String areaAt1, String areaAt2) {
        this.nome = nome;
        this.data = data;
        this.cpf = cpf;
        this.endereco = endereco;
        this.areaAt1 = areaAt1;
        this.areaAt2 = areaAt2;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    public String getAreaAt1() {
        return areaAt1;
    }

    public void setAreaAt1(String areaAt1) {
        this.areaAt1 = areaAt1;
    }

    public String getAreaAt2() {
        return areaAt2;
    }

    public void setAreaAt2(String areaAt2) {
        this.areaAt2 = areaAt2;
    }
    
}
