/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author Peu
 */
public class Atendimento {
    
    private int codAt;
    private int codAg;
    private String dataAg;
    private String nomeAl;
    private int codAl;
    private String nomePac;
    private int codPac;
    private String dataAt;
    private String servicoP;
    private int codSup;
    private String nomeSup;

    public int getCodAt() {
        return codAt;
    }

    public void setCodAt(int codAt) {
        this.codAt = codAt;
    }

    public int getCodAg() {
        return codAg;
    }

    public void setCodAg(int codAg) {
        this.codAg = codAg;
    }

    public String getDataAg() {
        return dataAg;
    }

    public void setDataAg(String dataAg) {
        this.dataAg = dataAg;
    }

    public String getNomeAl() {
        return nomeAl;
    }

    public void setNomeAl(String nomeAl) {
        this.nomeAl = nomeAl;
    }

    public int getCodAl() {
        return codAl;
    }

    public void setCodAl(int codAl) {
        this.codAl = codAl;
    }

    public String getNomePac() {
        return nomePac;
    }

    public void setNomePac(String nomePac) {
        this.nomePac = nomePac;
    }

    public int getCodPac() {
        return codPac;
    }

    public void setCodPac(int codPac) {
        this.codPac = codPac;
    }

    public String getDataAt() {
        return dataAt;
    }

    public void setDataAt(String dataAt) {
        this.dataAt = dataAt;
    }

    public String getServicoP() {
        return servicoP;
    }

    public void setServicoP(String servicoP) {
        this.servicoP = servicoP;
    }

    public int getCodSup() {
        return codSup;
    }

    public void setCodSup(int codSup) {
        this.codSup = codSup;
    }

    public String getNomeSup() {
        return nomeSup;
    }

    public void setNomeSup(String nomeSup) {
        this.nomeSup = nomeSup;
    }
    
    
    
}
