/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

import java.util.Scanner;

/**
 *
 * @author Peu
 */
public class Supervisor extends Pessoa{
    
    private String nome;
    private String curso;

    public Supervisor(String login, String senha, String nome, String curso) {
        super(login, senha);
        this.nome = nome;
        this.curso = curso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    
    public Supervisor cadastrarSUP(){
        Scanner scan = new Scanner(System.in);
        System.out.print("Nome do supervisor: ");
        nome = scan.nextLine();
        System.out.print("Curso do supervisor: ");
        curso = scan.nextLine();
        System.out.print("Login do supervisor: ");
        setLogin(scan.nextLine());
        System.out.print("Senha do supervisor: ");
        setSenha(scan.nextLine());
        return new Supervisor(getLogin(), getSenha(), nome, curso);
    }
    
    /*public Supervisor editarSUP(Supervisor s){
        Scanner scan = new Scanner(System.in);
        System.out.print("Nome do Aluno: ");
        nome = scan.nextLine();
        System.out.print("curso do aluno: ");
        curso = scan.nextLine();
        if(s.getNome().equals(nome) && s.getCurso().equals(curso)){
            return s;
        }
        return new Supervisor(nome, curso);
    
    }*/
    
    public void removerSUP(int cod){
        String sql = "DELETE FROM " + "`Clinica`.`Supervisor`" + " WHERE cod = ?";
        
    }
    
}
